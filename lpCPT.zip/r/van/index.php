<?php
include('../../settings.php');
header('Location: '.$offer_url, true, 302);
exit;
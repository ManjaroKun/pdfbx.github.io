<?php
$lp_domain = 'https://hq-audio.net'; //set domain and directory to landing page files. NO SLASH ON END.

$meta_title = "Get Unlimited Free R$"; //page title displayed in browser tab.

$meta_description = "Best blog guide to get free R$"; //not displayed on page. only for meta tags.

$img_above_header_text = '/img/ssa.png'; //image at top of page.

$center_img = '/img/body.png'; //change to image url of choice.

$google_reCaptcha_site_key = '6LeOhz0kAAAAAKyNP4m_FKcZ2AxyPVLc27UA13m3'; //get sitekey info at https://www.google.com/recaptcha/admin/ make sure you create reCAPTCHA type:v2 Checkbox, not v3.

$google_reCaptcha_secret_key = '6LeOhz0kAAAAAMOt2Pcclvy7426h4iNjSbyE2me-';

$offer_url = "https://google.com/"; //set your cpa link here.

$whitepage = 'https://www.roblox.com/upgrades/robux?ctx-nav'; //non-cpa page displayed to bots and proxies after completing captcha.

$proxycheck_api_key = '656821-tbl4qg-654958-g771g6';
?>